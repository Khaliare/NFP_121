
public enum Mode { PLEINE, CREUSE };
